.. _gitea geizhals:

========
Geizhals
========

.. automodule:: searx.engines.geizhals
  :members:
