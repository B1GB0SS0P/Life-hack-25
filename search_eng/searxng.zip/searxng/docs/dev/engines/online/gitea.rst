.. _gitea engine:

=====
Gitea
=====

.. automodule:: searx.engines.gitea
  :members:
