.. _mrs engine:

=========================
Matrix Rooms Search (MRS)
=========================

.. contents:: Contents
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.mrs
   :members:
