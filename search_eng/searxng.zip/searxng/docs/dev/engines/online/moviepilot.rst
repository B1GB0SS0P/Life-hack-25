.. _moviepilot engine:

==========
Moviepilot
==========

.. contents:: Contents
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.moviepilot
   :members:
