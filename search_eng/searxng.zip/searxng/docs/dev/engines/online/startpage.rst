.. _startpage engines:

=================
Startpage Engines
=================

.. contents::
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.startpage
   :members:
