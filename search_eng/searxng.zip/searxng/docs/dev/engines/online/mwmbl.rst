.. _Mwmbl engine:

============
Mwmbl Engine
============

.. contents::
   :depth: 2
   :local:
   :backlinks: entry


.. _mwmbl web engine:

Mwmbl WEB
=========

.. automodule:: searx.engines.mwmbl
  :members:


.. _mwmbl autocomplete:

Mwmbl Autocomplete
==================

.. autofunction:: searx.autocomplete.mwmbl
