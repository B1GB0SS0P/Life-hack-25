.. _core engine:

====
CORE
====

.. contents::
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.core
   :members:
