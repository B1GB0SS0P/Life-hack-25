.. _huggingface engine:

============
Hugging Face
============

.. automodule:: searx.engines.huggingface
   :members:
