.. _chinaso engine:

=======
ChinaSo
=======

.. automodule:: searx.engines.chinaso
   :members:
