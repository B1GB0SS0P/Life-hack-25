.. _lemmy engine:

=====
Lemmy
=====

.. contents:: Contents
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.lemmy
   :members:
