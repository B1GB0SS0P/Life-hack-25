.. _discourse engine:

================
Discourse Forums
================

.. automodule:: searx.engines.discourse
   :members:
