.. _loc engine:

===================
Library of Congress
===================

.. contents:: Contents
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.loc
  :members:
