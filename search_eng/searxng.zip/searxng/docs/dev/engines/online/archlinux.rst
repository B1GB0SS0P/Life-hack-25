.. _archlinux engine:

==========
Arch Linux
==========

.. contents::
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.archlinux
  :members:

