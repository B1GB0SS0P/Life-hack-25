.. _seekr engine:

=============
Seekr Engines
=============

.. contents:: Contents
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.seekr
  :members:
