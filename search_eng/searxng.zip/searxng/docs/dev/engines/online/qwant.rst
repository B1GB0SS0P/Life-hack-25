.. _qwant engine:

=====
Qwant
=====

.. contents:: Contents
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.qwant
   :members:
