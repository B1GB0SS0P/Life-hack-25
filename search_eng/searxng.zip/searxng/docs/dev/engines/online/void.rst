.. _voidlinux engine:

==========================
Void Linux binary packages
==========================

.. contents:: Contents
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.voidlinux
  :members:
