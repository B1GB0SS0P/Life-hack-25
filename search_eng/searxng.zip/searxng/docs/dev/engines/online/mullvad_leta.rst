.. _voidlinux mullvad_leta:

============
Mullvad-Leta
============

.. automodule:: searx.engines.mullvad_leta
   :members:
