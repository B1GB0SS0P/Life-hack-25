.. _gitlab engine:

======
GitLab
======

.. automodule:: searx.engines.gitlab
   :members:
