.. _searx.engines loader:

========================
SearXNG's engines loader
========================

.. automodule:: searx.engines
  :members:

