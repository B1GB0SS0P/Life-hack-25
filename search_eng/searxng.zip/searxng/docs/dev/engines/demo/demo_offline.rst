.. _demo offline engine:

===================
Demo Offline Engine
===================

.. contents::
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.engines.demo_offline
  :members:

