.. _plugins.calculator:

==========
Calculator
==========

.. automodule:: searx.plugins.calculator
   :members:
