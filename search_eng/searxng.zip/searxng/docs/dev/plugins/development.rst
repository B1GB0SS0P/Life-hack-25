.. _dev plugin:

==================
Plugin Development
==================

.. automodule:: searx.plugins
