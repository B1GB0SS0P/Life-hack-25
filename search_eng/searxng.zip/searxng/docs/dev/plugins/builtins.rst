.. _builtin plugins:

================
Built-in Plugins
================

.. toctree::
   :maxdepth: 1

   calculator
   hash_plugin
   hostnames
   self_info
   tor_check
   unit_converter
