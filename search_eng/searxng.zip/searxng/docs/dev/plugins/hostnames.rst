.. _hostnames plugin:

=========
Hostnames
=========

.. automodule:: searx.plugins.hostnames
   :members:
