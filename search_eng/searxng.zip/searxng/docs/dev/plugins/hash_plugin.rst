.. _hash_plugin plugin:

===========
Hash Values
===========

.. autoclass:: searx.plugins.hash_plugin.SXNGPlugin
   :members:
