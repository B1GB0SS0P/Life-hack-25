.. _unit converter plugin:

==============
Unit Converter
==============

.. automodule:: searx.plugins.unit_converter
   :members:
