.. _tor check plugin:

=========
Tor check
=========

.. automodule:: searx.plugins.tor_check
   :members:
