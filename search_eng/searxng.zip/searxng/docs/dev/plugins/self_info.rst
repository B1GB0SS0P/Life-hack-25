.. _self_info plugin:

=========
Self-Info
=========

.. autoclass:: searx.plugins.self_info.SXNGPlugin
   :members:
