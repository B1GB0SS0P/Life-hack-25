.. _extended_types.:

==============
Extended Types
==============

.. automodule:: searx.extended_types
