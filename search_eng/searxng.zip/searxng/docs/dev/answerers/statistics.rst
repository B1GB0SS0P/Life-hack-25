.. _answerer.statistics:

==========
Statistics
==========

.. autoclass:: searx.answerers.statistics.SXNGAnswerer
   :members:
