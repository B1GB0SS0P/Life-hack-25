.. _builtin answerers:

==================
Built-in Answerers
==================

.. toctree::
   :maxdepth: 1

   random
   statistics
