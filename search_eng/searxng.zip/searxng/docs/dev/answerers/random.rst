.. _answerer.random:

======
Random
======

.. autoclass:: searx.answerers.random.SXNGAnswerer
   :members:
