.. _dev answerers:

====================
Answerer Development
====================

.. automodule:: searx.answerers
