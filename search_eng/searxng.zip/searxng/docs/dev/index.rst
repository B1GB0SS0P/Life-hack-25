=======================
Developer documentation
=======================

.. toctree::
   :maxdepth: 2

   quickstart
   commits
   rtm_asdf
   contribution_guide
   extended_types
   engines/index
   result_types/index
   templates
   search_api
   plugins/index
   answerers/index
   translation
   lxcdev
   makefile
   reST
   searxng_extra/index
