======
Result
======

.. automodule:: searx.result_types._base
