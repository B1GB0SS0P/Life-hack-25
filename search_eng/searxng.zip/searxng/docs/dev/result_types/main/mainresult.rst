.. _result_types.mainresult:

.. autoclass:: searx.result_types._base.MainResult
   :members:
