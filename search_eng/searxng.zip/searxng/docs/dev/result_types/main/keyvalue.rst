.. _result_types.keyvalue:

=================
Key-Value Results
=================

.. automodule:: searx.result_types.keyvalue
