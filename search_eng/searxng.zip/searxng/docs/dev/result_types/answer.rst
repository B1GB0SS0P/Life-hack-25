.. _result_types.answer:

==============
Answer Results
==============

The :ref:`area answer results` is an area in which additional information can
be displayed.

.. automodule:: searx.result_types.answer
