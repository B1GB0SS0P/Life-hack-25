.. _about SearXNG:

.. include:: about.md
   :parser: myst_parser.sphinx_
