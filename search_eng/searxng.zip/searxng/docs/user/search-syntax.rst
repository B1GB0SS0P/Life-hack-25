.. _search-syntax:

.. include:: search-syntax.md
   :parser: myst_parser.sphinx_
