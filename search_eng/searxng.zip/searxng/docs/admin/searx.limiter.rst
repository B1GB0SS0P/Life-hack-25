.. _limiter:

=======
Limiter
=======

.. sidebar:: info

   The limiter requires a :ref:`Redis <settings redis>` database.

.. contents::
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.limiter
   :members:
