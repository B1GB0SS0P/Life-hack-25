.. _searx.cache:

======
Caches
======

.. automodule:: searx.cache
   :members:
