.. _searx.exceptions:

==================
SearXNG Exceptions
==================

.. automodule:: searx.exceptions
  :members:
