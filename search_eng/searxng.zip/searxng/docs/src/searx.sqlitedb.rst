.. _sqlite db:

=========
SQLite DB
=========

.. automodule:: searx.sqlitedb
   :members:
