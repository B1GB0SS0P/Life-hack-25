.. _searx.locales:

=======
Locales
=======

.. contents::
   :depth: 2
   :local:
   :backlinks: entry

.. automodule:: searx.locales
   :members:


