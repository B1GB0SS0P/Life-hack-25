.. _searx.redis:

=============
Redis Library
=============

.. automodule:: searx.redislib
  :members:
