.. _weather:

=======
Weather
=======

.. automodule:: searx.weather
   :members:
