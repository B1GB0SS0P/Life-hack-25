.. _searx.settings_loader:

===============
Settings Loader
===============

.. automodule:: searx.settings_loader
   :members:
