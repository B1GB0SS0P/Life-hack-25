=====================
MEMO vite development
=====================

Local install::

  # in folder ./client/simple/
  $ npm install

Start development server::

  $ ./manage vite.simple.dev

  # in folder ./client/simple/
  $ npm exec -- vite

Fix source code::

  # in folder ./client/simple/
  $ npm run fix

Fix & Build::

  $ ./manage vite.simple.build
