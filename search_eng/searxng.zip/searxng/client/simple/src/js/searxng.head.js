import "./head/00_init.js";
